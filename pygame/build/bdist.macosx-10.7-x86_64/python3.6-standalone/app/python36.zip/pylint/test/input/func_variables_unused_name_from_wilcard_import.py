"""check unused import from a wildcard import"""
# pylint: disable=no-absolute-import
from input.func_w0611 import *
